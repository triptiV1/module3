#!/usr/bin/env python3
"""
CSC580 CTA 3.2 – Predicting Fuel Efficiency Using TensorFlow (Auto MPG)
Author: Tripti Vishwakarma

This script downloads the UCI Auto MPG dataset and builds TensorFlow regression models
(using tf.keras) to predict MPG. It follows the required assignment steps, and saves plots
and text outputs for screenshots.

Outputs are written to the ./outputs/ directory.

Usage:
  python3 auto_mpg_regression.py

Optional flags:
  --epochs 1000         # number of training epochs (default 1000)

Dependencies (see requirements.txt):
  - tensorflow
  - pandas, numpy, matplotlib, seaborn
  - tensorflow-docs (optional) – if unavailable, a fallback plotting path is used
"""
import argparse
import io
import os
import pathlib
import sys
from datetime import datetime

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers

# Try to import tensorflow_docs; fall back to custom plotting if not available
try:
    import tensorflow_docs as tfdocs  # type: ignore
    import tensorflow_docs.plots  # type: ignore
    import tensorflow_docs.modeling  # type: ignore
    TFDOCS_AVAILABLE = True
except Exception:
    TFDOCS_AVAILABLE = False

# Word document generation removed per user request.


def ensure_outputs_dir(base_dir: pathlib.Path) -> pathlib.Path:
    out_dir = base_dir / "outputs"
    out_dir.mkdir(parents=True, exist_ok=True)
    return out_dir


def step_header(title: str):
    print("\n" + "=" * 80)
    print(title)
    print("=" * 80)


def download_dataset() -> str:
    step_header("Step 1: Download the dataset using keras get_file")
    url = (
        "http://archive.ics.uci.edu/ml/machine-learning-databases/auto-mpg/auto-mpg.data"
    )
    dataset_path = keras.utils.get_file("auto-mpg.data", url)
    print(f"Dataset downloaded to: {dataset_path}")
    return dataset_path


def load_dataset(dataset_path: str) -> pd.DataFrame:
    step_header("Step 2: Import dataset using Pandas")
    column_names = [
        "MPG",
        "Cylinders",
        "Displacement",
        "Horsepower",
        "Weight",
        "Acceleration",
        "Model Year",
        "Origin",
    ]
    raw_dataset = pd.read_csv(
        dataset_path,
        names=column_names,
        na_values="?",
        comment="\t",
        sep=" ",
        skipinitialspace=True,
    )
    dataset = raw_dataset.copy()

    # Drop rows with missing values (as per TF tutorial handling)
    dataset = dataset.dropna()

    # One-hot encode 'Origin' (1=USA, 2=Europe, 3=Japan)
    origin = dataset.pop("Origin")
    dataset["USA"] = (origin == 1) * 1.0
    dataset["Europe"] = (origin == 2) * 1.0
    dataset["Japan"] = (origin == 3) * 1.0

    print("Dataset loaded. Tail (for screenshot):")
    print(dataset.tail())
    return dataset


def save_tail(df: pd.DataFrame, path: pathlib.Path, rows: int = 5):
    with open(path, "w", encoding="utf-8") as f:
        f.write(df.tail(rows).to_string())


def train_test_split(dataset: pd.DataFrame):
    step_header("Step 4: Split the data into train and test")
    train_dataset = dataset.sample(frac=0.8, random_state=0)
    test_dataset = dataset.drop(train_dataset.index)
    print(f"Train size: {len(train_dataset)} | Test size: {len(test_dataset)}")
    return train_dataset, test_dataset


def pairplot(train_dataset: pd.DataFrame, out_path: pathlib.Path, show: bool = False):
    step_header("Step 5: Inspect the data (seaborn pairplot)")
    sns.set(style="ticks")
    g = sns.pairplot(
        train_dataset[["MPG", "Cylinders", "Displacement", "Weight"]],
        diag_kind="kde",
    )
    g.fig.suptitle("Auto MPG Pairplot (Train)", y=1.02)
    g.savefig(out_path, bbox_inches="tight", dpi=150)
    print(f"Pairplot saved to {out_path}")
    if show:
        plt.show()


def describe_train_stats(train_dataset: pd.DataFrame) -> pd.DataFrame:
    step_header("Step 7: Review the statistics (exclude MPG)")
    train_stats = train_dataset.describe().transpose()
    if "MPG" in train_stats.index:
        train_stats = train_stats.drop(index=["MPG"])  # pop equivalent
    print("Train stats (tail for screenshot):")
    print(train_stats.tail())
    return train_stats


def split_features_labels(train_dataset: pd.DataFrame, test_dataset: pd.DataFrame):
    step_header("Steps 9-10: Split features from labels (MPG)")
    train_labels = train_dataset.pop("MPG")
    test_labels = test_dataset.pop("MPG")
    print("Labels separated. Example train labels tail:")
    print(train_labels.tail())
    return train_dataset, test_dataset, train_labels, test_labels


def build_normalizer(train_stats: pd.DataFrame):
    step_header("Step 11: Normalize the data (z-score)")
    means = train_stats["mean"]
    stds = train_stats["std"]

    def norm(x: pd.DataFrame) -> pd.DataFrame:
        return (x - means) / stds

    return norm


def build_model(input_dim: int, loss: str = "mse") -> keras.Model:
    step_header("Step 12: Build the model (Sequential: 64-ReLU, 64-ReLU, 1)")
    model = keras.Sequential(
        [
            layers.Dense(64, activation="relu", input_shape=[input_dim]),
            layers.Dense(64, activation="relu"),
            layers.Dense(1),
        ]
    )
    optimizer = tf.keras.optimizers.RMSprop(0.001)
    model.compile(loss=loss, optimizer=optimizer, metrics=["mae", "mse"])
    print(f"Model compiled with loss={loss}")
    return model


def capture_model_summary(model: keras.Model) -> str:
    step_header("Step 13: Inspect the model (.summary)")
    buf = io.StringIO()
    model.summary(print_fn=lambda s: buf.write(s + "\n"))
    summary_str = buf.getvalue()
    print(summary_str)
    return summary_str


def train_model(model: keras.Model, x_train, y_train, epochs: int, val_split: float = 0.2):
    step_header("Steps 17-18: Train the model")
    callbacks = []
    if TFDOCS_AVAILABLE:
        callbacks.append(tfdocs.modeling.EpochDots())
        verbose = 0
    else:
        verbose = 1  # basic progress if tfdocs not available

    history = model.fit(
        x_train,
        y_train,
        epochs=epochs,
        validation_split=val_split,
        verbose=verbose,
        callbacks=callbacks,
    )
    return history


def plot_history(histories: dict, metric: str, out_path: pathlib.Path, show: bool = False):
    plt.figure(figsize=(7, 4))
    if TFDOCS_AVAILABLE:
        plotter = tfdocs.plots.HistoryPlotter(smoothing_std=2)
        plotter.plot(histories, metric=metric)
    else:
        # Fallback: simple matplotlib plotting
        for name, h in histories.items():
            y = h.history.get(metric, None)
            if y is not None:
                plt.plot(h.epoch, y, label=name)
    plt.xlabel("Epoch")
    plt.ylabel(metric.upper())
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(out_path, dpi=150)
    if show:
        plt.show()
    plt.close()
    print(f"Saved {metric} plot to {out_path}")


def write_text(path: pathlib.Path, content: str):
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)


# generate_word_report removed


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--epochs", type=int, default=1000)
    parser.add_argument("--show-plots", action="store_true", dest="show_plots",
                        help="Display pairplot and training curves in windows while also saving them")
    args = parser.parse_args()

    base_dir = pathlib.Path(__file__).resolve().parent
    out_dir = ensure_outputs_dir(base_dir)

    print(f"TensorFlow version: {tf.__version__}")

    # Step 1-3: Download and load
    dataset_path = download_dataset()
    dataset = load_dataset(dataset_path)

    # Save a small tail of the cleaned dataset for screenshot and PRINT it
    tail_txt = out_dir / "dataset_tail.txt"
    tail_str = dataset.tail().to_string()
    write_text(tail_txt, tail_str)
    print(tail_str)

    train_dataset, test_dataset = train_test_split(dataset)

    # Step 5-6: Pairplot and screenshot
    pairplot_path = out_dir / "pairplot.png"
    pairplot(train_dataset, pairplot_path, show=args.show_plots)

    # Step 7-8: Stats
    train_stats = describe_train_stats(train_dataset)
    train_stats_tail = train_stats.tail().to_string()
    write_text(out_dir / "train_stats_tail.txt", train_stats_tail)
    print(train_stats_tail)

    # Steps 9-11: Features/labels and normalization
    train_dataset, test_dataset, train_labels, test_labels = split_features_labels(
        train_dataset, test_dataset
    )
    # Build normalizer and apply to train/test
    normalizer = build_normalizer(train_stats)
    normed_train_data = normalizer(train_dataset)
    normed_test_data = normalizer(test_dataset)

    # Build two identical models with different losses (MSE and MAE)
    input_dim = len(train_dataset.keys())
    model_mse = build_model(input_dim, loss="mse")
    summary_mse = capture_model_summary(model_mse)
    write_text(out_dir / "model_summary_mse.txt", summary_mse)

    model_mae = build_model(input_dim, loss="mae")
    summary_mae = capture_model_summary(model_mae)
    write_text(out_dir / "model_summary_mae.txt", summary_mae)

    # Train both models and show progress
    EPOCHS = int(args.epochs)
    history_mse = train_model(model_mse, normed_train_data, train_labels, epochs=EPOCHS)
    history_mae = train_model(model_mae, normed_train_data, train_labels, epochs=EPOCHS)

    # Step 19-21: Visualize training progress
    hist_df_mse = pd.DataFrame(history_mse.history)
    hist_df_mse["epoch"] = history_mse.epoch

    hist_df_mae = pd.DataFrame(history_mae.history)
    hist_df_mae["epoch"] = history_mae.epoch

    # Save tails
    history_tail_txt = out_dir / "history_tail_mse.txt"
    save_tail(hist_df_mse, history_tail_txt)
    history_tail_mae_txt = out_dir / "history_tail_mae.txt"
    save_tail(hist_df_mae, history_tail_mae_txt)

    # Print tails
    print("History tail (MSE-loss model):")
    print(hist_df_mse.tail())
    print("History tail (MAE-loss model):")
    print(hist_df_mae.tail())

    # Plots for MAE and MSE comparing both models
    mae_plot = out_dir / "history_mae.png"
    mse_plot = out_dir / "history_mse.png"
    histories = {"MSE-loss": history_mse, "MAE-loss": history_mae}
    plot_history(histories, metric="mae", out_path=mae_plot, show=args.show_plots)
    plot_history(histories, metric="mse", out_path=mse_plot, show=args.show_plots)

    # Simple evaluation on test set (optional extra info)
    step_header("Optional: Evaluate on test set")
    # Use the normalized test data computed earlier
    test_mse_eval = model_mse.evaluate(normed_test_data, test_labels, verbose=0)
    test_mae_eval = model_mae.evaluate(normed_test_data, test_labels, verbose=0)
    print(f"Test eval (MSE-loss model): loss={test_mse_eval[0]:.4f}, MAE={test_mse_eval[1]:.4f}, MSE={test_mse_eval[2]:.4f}")
    print(f"Test eval (MAE-loss model): loss={test_mae_eval[0]:.4f}, MAE={test_mae_eval[1]:.4f}, MSE={test_mae_eval[2]:.4f}")
    # Submission ZIP generation removed per user request; nothing to package here.


if __name__ == "__main__":
    # Make TF deterministic-ish for reproducibility
    os.environ["PYTHONHASHSEED"] = "0"
    tf.random.set_seed(0)
    np.random.seed(0)
    main()
